title: The Videos from the Meetup
author: ryandahl
date: Fri Aug 12 2011 00:14:34 GMT-0700 (PDT)
status: publish
category: Uncategorized
slug: the-videos-from-node-meetup

Uber, Voxer, and Joyent described how they use Node in production

<a href="http://www.joyent.com/blog/node-js-meetup-distributed-web-architectures/">http://www.joyent.com/blog/node-js-meetup-distributed-web-architectures/</a>
