title: Bert Belder - libuv at LXJS 2012
slug: bert-belder-libuv-lxjs-2012
category: video
date: Sun Sep 30 10:28:45 PDT 2012

Node core committer Bert Belder gave a talk at
[LXJS](http://2012.lxjs.org/).  If you are interested in how Node does
asynchronous I/O across platforms, then you should definitely watch
this video.

<iframe width="640" height="360"
src="http://www.youtube.com/embed/nGn60vDSxQ4" frameborder="0"
allowfullscreen></iframe>
